#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool
from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import NavSatFix # We now publish GPS
from ament_index_python.packages import get_package_share_directory
import os
import time

class MissionManager(Node):
    def __init__(self):
        super().__init__('coordinate_follower')
        self.internal_state = 'IDLE' 
        self.mission_goals = []
        self.current_goal_index = -1
        
        # Simulation Variables
        self.drive_duration = 5.0 # Seconds to reach goal
        self.drive_start_time = 0
        
        # Position State (Defaults to Goa if no mission loaded)
        self.current_lat = 15.3911
        self.current_lon = 73.8782
        self.start_lat = 0.0
        self.start_lon = 0.0
        self.target_lat = 0.0
        self.target_lon = 0.0

        home_dir = os.path.expanduser('~')
        self.mission_file_path = os.path.join(home_dir, 'flask_gcs', 'mission_plan.txt')
        
        # Publishers
        self.task_complete_pub = self.create_publisher(Bool, '/auto/task_complete', 10)
        self.velocity_pub = self.create_publisher(Twist, '/auto/cmd_vel', 10)
        self.gcs_command_pub = self.create_publisher(String, '/gcs/command', 10)
        
        # --- NEW: GPS PUBLISHER (Fakes MAVROS) ---
        self.gps_pub = self.create_publisher(NavSatFix, '/mavros/global_position/global', 10)

        # Subscribers
        self.create_subscription(String, '/rover_state', self.state_callback, 10)
        self.create_subscription(String, '/gcs/command', self.gcs_command_callback, 10)
        
        # Timer
        self.timer = self.create_timer(0.1, self.control_loop) # 10Hz
        
        self.load_mission()
        
        # Initialize position to first goal if available
        if self.mission_goals:
            first_goal = self.mission_goals[0]
            self.current_lat = first_goal.x
            self.current_lon = first_goal.y
            self.get_logger().info(f'Initialized position to first goal: {self.current_lat}, {self.current_lon}')
            self.get_logger().info('Waiting for "PROCEED".')
        else:
             self.get_logger().error('No mission goals found!')

    def load_mission(self):
        self.get_logger().info(f'Loading mission plan...')
        try:
            self.mission_goals = [] # Clear old goals
            with open(self.mission_file_path, 'r') as f:
                for line in f:
                    parts = line.strip().split(',')
                    if len(parts) == 4: 
                        try:
                            lat = float(parts[2])
                            lon = float(parts[3])
                            # Store lat in x, lon in y for convenience
                            self.mission_goals.append(Point(x=lat, y=lon))
                        except ValueError: pass
            self.get_logger().info(f'Loaded {len(self.mission_goals)} goals.')
        except Exception as e:
            self.get_logger().error(f'Failed to load mission file: {e}')

    def gcs_command_callback(self, msg):
        command = msg.data.upper()
        if command == 'PROCEED' and self.internal_state == 'WAITING_FOR_PROCEED':
            self.load_mission() # Reload in case user added points
            self.request_next_goal()

    def request_next_goal(self):
        self.current_goal_index += 1
        if self.current_goal_index < len(self.mission_goals):
            goal = self.mission_goals[self.current_goal_index]
            
            # Set up the interpolation leg
            self.start_lat = self.current_lat
            self.start_lon = self.current_lon
            self.target_lat = goal.x
            self.target_lon = goal.y
            
            self.get_logger().info(f'Driving to Goal {self.current_goal_index + 1}: ({self.target_lat}, {self.target_lon})')
            
            # Send command to switch state
            self.gcs_command_pub.publish(String(data="PROCEED"))
        else:
            self.get_logger().info('Mission Complete. Waiting for new goals.')
            self.internal_state = 'WAITING_FOR_PROCEED'
            self.current_goal_index = len(self.mission_goals) - 1

    def state_callback(self, msg):
        rover_state = msg.data.upper()
        if rover_state == 'AUTONOMOUS' and self.internal_state == 'WAITING_FOR_PROCEED':
            self.internal_state = 'AUTONOMOUS_ACTIVE'
            self.drive_start_time = time.time()
        elif rover_state == 'MANUAL' and self.internal_state == 'AUTONOMOUS_ACTIVE':
            self.internal_state = 'WAITING_FOR_PROCEED'

    def control_loop(self):
        # ALWAYS publish GPS (even when stopped), so the map knows where we are
        gps_msg = NavSatFix()
        gps_msg.latitude = self.current_lat
        gps_msg.longitude = self.current_lon
        gps_msg.header.frame_id = "map"
        self.gps_pub.publish(gps_msg)

        if self.internal_state != 'AUTONOMOUS_ACTIVE':
            return

        # --- SIMULATED MOVEMENT LOGIC (Linear Interpolation) ---
        elapsed = time.time() - self.drive_start_time
        progress = min(elapsed / self.drive_duration, 1.0) # 0.0 to 1.0

        # Math: Current = Start + (Target - Start) * Progress
        self.current_lat = self.start_lat + (self.target_lat - self.start_lat) * progress
        self.current_lon = self.start_lon + (self.target_lon - self.start_lon) * progress

        # Drive
        if progress < 1.0:
            cmd = Twist()
            cmd.linear.x = 0.5
            self.velocity_pub.publish(cmd)
        else:
            # Arrived
            self.get_logger().info('Arrived at goal.')
            self.velocity_pub.publish(Twist()) 
            self.task_complete_pub.publish(Bool(data=True))

def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()